# GoldValue Calculator
Calculadora para valores de ouro com React.