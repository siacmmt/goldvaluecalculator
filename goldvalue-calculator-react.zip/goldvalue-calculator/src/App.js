import React from 'react';
import OuroCalculator from './OuroCalculator';

function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>GoldValue Calculator</h1>
      <OuroCalculator />
    </div>
  );
}

export default App;
